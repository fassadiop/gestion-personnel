# apps/rh/models/demission.py

"""
==========================================================
SGCP - Système de Gestion de Carrière du Personnel

Fichier : apps/rh/models/demission.py

Description :
    Informations spécifiques à une démission.

    Ce modèle complète un événement de carrière de type
    DEMISSION.

Auteur : SGCP
Version : 1.0
==========================================================
"""

from django.db import models

from apps.rh.models.base_evenement import BaseEvenementModel


class Demission(BaseEvenementModel):
    """
    Informations spécifiques à une démission.

    La démission met fin définitivement à la relation
    entre l'agent et l'administration.

    Les informations communes (agent, acte administratif,
    dates, documents, etc.) sont portées par
    EvenementCarriere.
    """

    motif = models.TextField(
        blank=True,
        default="",
        verbose_name="Motif",
        help_text="Motif de la démission.",
    )

    observation = models.TextField(
        blank=True,
        default="",
        verbose_name="Observations",
        help_text="Observations complémentaires.",
    )

    class Meta:
        db_table = "demission"

        verbose_name = "Démission"
        verbose_name_plural = "Démissions"

        ordering = [
            "-date_effet",
            "-id",
        ]

    def __str__(self):
        return (
            f"Démission ({self.agent})"
        )