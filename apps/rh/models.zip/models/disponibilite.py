# apps/rh/models/disponibilite.py

from django.db import models

from apps.rh.core.base import BaseStructureModel

from apps.rh.models.evenement import EvenementCarriere
from apps.rh.models.referentiels import PositionAdministrative


class Disponibilite(BaseStructureModel):
    """
    Informations spécifiques à une disponibilité.

    Une disponibilité place temporairement un agent
    hors de son administration.

    Elle entraîne un changement de position
    administrative sans créer de nouvelle affectation.

    Ce modèle ne contient que les informations
    nécessaires à la disponibilité.
    """

    evenement = models.OneToOneField(
        EvenementCarriere,
        on_delete=models.CASCADE,
        related_name="disponibilite",
        verbose_name="Événement de carrière",
        help_text="Événement de disponibilité.",
    )

    position_administrative = models.ForeignKey(
        PositionAdministrative,
        on_delete=models.PROTECT,
        related_name="disponibilites",
        verbose_name="Position administrative",
    )

    date_debut = models.DateField(
        verbose_name="Date de début",
        help_text="Date de début de la disponibilité.",
    )

    date_fin_prevue = models.DateField(
        verbose_name="Date de fin prévisionnelle",
        help_text="Date prévue de fin de la disponibilité.",
        null=True,
        blank=True,
    )

    class Meta:
        db_table = "disponibilite"

        verbose_name = "Disponibilité"
        verbose_name_plural = "Disponibilités"

        ordering = [
            "-date_debut",
            "-id",
        ]

        constraints = [

            models.CheckConstraint(
                condition=(
                    models.Q(date_fin_prevue__isnull=True)
                    |
                    models.Q(
                        date_fin_prevue__gte=models.F("date_debut")
                    )
                ),
                name="ck_disponibilite_dates",
            ),

        ]

        indexes = [

            models.Index(fields=["position_administrative"]),

            models.Index(fields=["date_debut"]),

            models.Index(fields=["date_fin_prevue"]),

        ]

    def __str__(self):

        return (
            f"Disponibilité de {self.evenement.agent}"
        )