# apps/rh/models/sanction.py

from django.db import models

from apps.rh.models.base_evenement import BaseEvenementModel
from apps.rh.models.referentiels import TypeSanction


class Sanction(BaseEvenementModel):
    """
    Sanction disciplinaire devenue définitive.

    Cette entité représente la décision disciplinaire
    ayant un effet sur la carrière de l'agent.

    Les informations communes (agent, acte administratif,
    autorité signataire, dates, etc.) sont portées par
    EvenementCarriere.
    """

    type_sanction = models.ForeignKey(
        TypeSanction,
        on_delete=models.PROTECT,
        related_name="sanctions",
        verbose_name="Type de sanction",
        help_text="Nature de la sanction disciplinaire.",
    )

    date_faits = models.DateField(
        verbose_name="Date des faits",
        help_text="Date à laquelle les faits reprochés ont été commis.",
    )

    faits_reproches = models.TextField(
        blank=True,
        default="",
        verbose_name="Faits reprochés",
        help_text="Description des faits ayant motivé la sanction disciplinaire.",
    )

    class Meta:
        db_table = "sanction"

        verbose_name = "Sanction disciplinaire"
        verbose_name_plural = "Sanctions disciplinaires"

        ordering = [
            "-evenement__date_effet",
            "type_sanction__libelle",
        ]

        constraints = [

            models.CheckConstraint(
                condition=models.Q(
                    date_faits__lte=models.F("evenement__date_effet")
                ),
                name="ck_sanction_date_faits",
            ),

        ]

        indexes = [

            models.Index(fields=["type_sanction"]),

            models.Index(fields=["date_faits"]),

        ]

    def __str__(self):
        return (
            f"{self.type_sanction.libelle} "
            f"({self.agent})"
        )
