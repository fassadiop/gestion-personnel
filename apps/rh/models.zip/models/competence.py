from django.core.exceptions import ValidationError
from django.db import models

from apps.rh.core.base import BaseModel
from apps.rh.models.agent import Agent
from apps.rh.models.formation import Formation
from apps.rh.models.referentiels import (
    NiveauCompetence,
    TypeCompetence,
)


class Competence(BaseModel):
    """
    Compétence métier.

    Une compétence représente un savoir, un savoir-faire
    ou un savoir-être pouvant être acquis par différents
    moyens (formation, expérience professionnelle,
    autoformation, certification, mission...).

    Elle constitue un référentiel métier réutilisable
    dans tout le SGCP.
    """

    code = models.CharField(
        max_length=30,
        verbose_name="Code",
        help_text="Code unique de la compétence.",
    )

    libelle = models.CharField(
        max_length=255,
        verbose_name="Libellé",
    )

    description = models.TextField(
        blank=True,
        default="",
        verbose_name="Description",
    )

    type_competence = models.ForeignKey(
        TypeCompetence,
        on_delete=models.PROTECT,
        related_name="competences",
        verbose_name="Type de compétence",
    )

    class Meta:
        db_table = "competence"

        verbose_name = "Compétence"
        verbose_name_plural = "Compétences"

        ordering = [
            "libelle",
        ]

        constraints = [

            models.UniqueConstraint(
                fields=["code"],
                name="uq_competence_code",
            ),

            models.UniqueConstraint(
                fields=["libelle"],
                name="uq_competence_libelle",
            ),

        ]

        indexes = [

            models.Index(fields=["code"]),

            models.Index(fields=["libelle"]),

            models.Index(fields=["type_competence"]),

        ]

    def __str__(self):
        return self.libelle


class AgentCompetence(BaseModel):
    """
    Compétence détenue par un agent.

    Cette entité matérialise les compétences réellement
    acquises par un agent, indépendamment de leur mode
    d'acquisition.
    """

    agent = models.ForeignKey(
        Agent,
        on_delete=models.PROTECT,
        related_name="competences",
        verbose_name="Agent",
        help_text="Agent possédant cette compétence.",
    )

    competence = models.ForeignKey(
        Competence,
        on_delete=models.PROTECT,
        related_name="agents",
        verbose_name="Compétence",
        help_text="Compétence détenue par l'agent.",
    )

    niveau = models.ForeignKey(
        NiveauCompetence,
        on_delete=models.PROTECT,
        related_name="competences_agents",
        verbose_name="Niveau",
        help_text="Niveau de maîtrise de la compétence.",
    )

    date_acquisition = models.DateField(
        null=True,
        blank=True,
        verbose_name="Date d'acquisition",
        help_text="Date à laquelle la compétence a été acquise.",
    )

    date_validation = models.DateField(
        null=True,
        blank=True,
        verbose_name="Date de validation",
        help_text="Date de validation officielle de la compétence.",
    )

    observations = models.TextField(
        blank=True,
        default="",
        verbose_name="Observations",
        help_text="Observations complémentaires.",
    )

    class Meta:
        db_table = "agent_competence"

        verbose_name = "Compétence de l'agent"
        verbose_name_plural = "Compétences des agents"

        ordering = [
            "agent__nom",
            "agent__prenom",
            "competence__libelle",
        ]

        constraints = [

            models.UniqueConstraint(
                fields=[
                    "agent",
                    "competence",
                ],
                name="uq_agent_competence",
            ),

            models.CheckConstraint(
                condition=(
                    models.Q(date_validation__isnull=True)
                    |
                    models.Q(date_acquisition__isnull=True)
                    |
                    models.Q(
                        date_validation__gte=models.F("date_acquisition")
                    )
                ),
                name="ck_agent_competence_dates",
            ),

        ]

        indexes = [

            models.Index(fields=["agent"]),

            models.Index(fields=["competence"]),

            models.Index(fields=["niveau"]),

            models.Index(fields=["date_validation"]),

        ]

    @property
    def est_validee(self):
        """
        Indique si la compétence a été validée.
        """
        return self.date_validation is not None

    def clean(self):
        super().clean()

        if (
            self.date_validation
            and self.date_acquisition
            and self.date_validation < self.date_acquisition
        ):
            raise ValidationError(
                {
                    "date_validation": (
                        "La date de validation ne peut pas être "
                        "antérieure à la date d'acquisition."
                    )
                }
            )

    def __str__(self):
        return (
            f"{self.agent} - "
            f"{self.competence.libelle}"
        )


class FormationCompetence(BaseModel):
    """
    Association entre une formation et les compétences
    qu'elle permet d'acquérir ou de renforcer.

    Une formation peut développer plusieurs compétences
    et une même compétence peut être développée par
    plusieurs formations.
    """

    formation = models.ForeignKey(
        Formation,
        on_delete=models.CASCADE,
        related_name="competences",
        verbose_name="Formation",
        help_text="Formation concernée.",
    )

    competence = models.ForeignKey(
        Competence,
        on_delete=models.PROTECT,
        related_name="formations",
        verbose_name="Compétence",
        help_text="Compétence développée par la formation.",
    )

    class Meta:
        db_table = "formation_competence"

        verbose_name = "Compétence de formation"
        verbose_name_plural = "Compétences des formations"

        ordering = [
            "formation",
            "competence__libelle",
        ]

        constraints = [

            models.UniqueConstraint(
                fields=[
                    "formation",
                    "competence",
                ],
                name="uq_formation_competence",
            ),

        ]

        indexes = [

            models.Index(fields=["formation"]),

            models.Index(fields=["competence"]),

        ]

    def __str__(self):
        return (
            f"{self.formation.intitule} - "
            f"{self.competence.libelle}"
        )
    
    def save(self, *args, **kwargs):
        """
        Exécute les validations métier avant sauvegarde.
        """
        self.full_clean()
        return super().save(*args, **kwargs)