# apps/rh/models/occupation.py

from django.db import models

from apps.rh.core.base import BaseStructureModel

from apps.rh.models.agent import Agent
from apps.rh.models.evenement import EvenementCarriere
from apps.rh.models.organisation import Poste


class OccupationPoste(BaseStructureModel):
    """
    Historique des occupations de poste.

    Cette entité permet d'historiser les différents agents
    ayant occupé un poste au cours du temps.

    Une occupation de poste est toujours créée à partir
    d'un événement de carrière.

    Exemples :

    - Nomination
    - Mutation
    - Affectation
    - Intérim
    - Remplacement
    """

    agent = models.ForeignKey(
        Agent,
        on_delete=models.PROTECT,
        related_name="occupations_poste",
        verbose_name="Agent",
        help_text="Agent occupant le poste.",
    )

    poste = models.ForeignKey(
        Poste,
        on_delete=models.PROTECT,
        related_name="occupations",
        verbose_name="Poste",
        help_text="Poste occupé.",
    )

    evenement = models.ForeignKey(
        EvenementCarriere,
        on_delete=models.PROTECT,
        related_name="occupations_poste",
        verbose_name="Événement de carrière",
        help_text="Événement ayant créé cette occupation.",
    )

    date_debut = models.DateField(
        verbose_name="Date de début",
        help_text="Date de début d'occupation du poste.",
    )

    date_fin = models.DateField(
        null=True,
        blank=True,
        verbose_name="Date de fin",
        help_text="Date de fin d'occupation du poste.",
    )

    class Meta:
        db_table = "occupation_poste"

        verbose_name = "Occupation de poste"
        verbose_name_plural = "Occupations de poste"

        ordering = [
            "-date_debut",
            "-id",
        ]

        constraints = [

            models.CheckConstraint(
                condition=(
                    models.Q(date_fin__isnull=True)
                    |
                    models.Q(date_fin__gte=models.F("date_debut"))
                ),
                name="ck_occupation_poste_dates",
            ),

            models.UniqueConstraint(
                fields=["poste"],
                condition=models.Q(date_fin__isnull=True),
                name="uq_poste_occupation_active",
            ),

        ]

        indexes = [

            models.Index(fields=["agent"]),

            models.Index(fields=["poste"]),

            models.Index(fields=["evenement"]),

            models.Index(fields=["date_debut"]),

            models.Index(fields=["date_fin"]),

            models.Index(fields=["poste", "date_fin"]),

        ]

    def __str__(self):
        if self.date_fin:
            periode = (
                f"{self.date_debut:%d/%m/%Y}"
                f" → "
                f"{self.date_fin:%d/%m/%Y}"
            )
        else:
            periode = (
                f"Depuis le {self.date_debut:%d/%m/%Y}"
            )

        return (
            f"{self.agent} — "
            f"{self.poste} "
            f"({periode})"
        )